<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Project rules
- All invoice math lives in `src/lib/invoice-engine.ts` as pure functions on integer minor units — keeps totals exact; never compute money with floats in components.
- Invoices and settings persist in browser localStorage via `src/lib/invoice-store.ts` (useSyncExternalStore) — no backend needed; read it only after hydration.
- Colors/fonts are semantic tokens and component classes (`.btn`, `.input`, `.card`, `.paper`) in `src/styles.css` — extend there, not inline.
