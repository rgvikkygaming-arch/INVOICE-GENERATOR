import {
  amountInWords,
  effectiveStatus,
  formatMoney,
  lateFee,
  TERMS,
  todayISO,
  type Computed,
  type Invoice,
} from "@/lib/invoice-engine";
import { StatusChip } from "./status-chip";

function fmtDate(iso: string) {
  if (!iso) return "—";
  const [y = 1970, m = 1, d = 1] = iso.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d)).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric", timeZone: "UTC" });
}

export function InvoiceDocument({ invoice, computed, asOf }: { invoice: Invoice; computed: Computed; asOf?: string }) {
  const c = computed;
  const cur = invoice.currency;
  const money = (n: number) => formatMoney(n, cur);
  const today = asOf ?? todayISO();
  const status = effectiveStatus(invoice, today);
  const fee = status === "overdue" ? lateFee(c.balanceDue, invoice.dueDate, today, invoice.lateFeeRate, invoice.lateFeeMode) : null;
  const termsLabel = TERMS.find((t) => t.value === invoice.terms)?.label ?? "";
  const inclusive = invoice.taxMode === "inclusive";

  return (
    <div id="invoice-paper" className="paper w-full p-6 text-[13px] leading-relaxed sm:p-10 print:p-0">
      <header className="flex flex-wrap items-start justify-between gap-6">
        <div className="min-w-0">
          <div className="font-display text-2xl font-bold tracking-tight">{invoice.from.name || "Your business"}</div>
          <div className="mt-1 whitespace-pre-line text-paper-muted">{invoice.from.address || "Business address"}</div>
          {invoice.from.email && <div className="text-paper-muted">{invoice.from.email}</div>}
          {invoice.from.taxId && <div className="text-paper-muted">Tax ID: {invoice.from.taxId}</div>}
        </div>
        <div className="text-right">
          <div className="font-display text-4xl font-extrabold uppercase tracking-tight text-primary">Invoice</div>
          <div className="num mt-1 text-sm font-semibold">{invoice.number || "—"}</div>
          <div className="mt-2">
            <StatusChip status={status} />
          </div>
        </div>
      </header>

      <div className="mt-8 grid grid-cols-2 gap-6 border-y border-paper-line py-5 sm:grid-cols-4">
        <div className="col-span-2">
          <div className="text-[10px] font-bold uppercase tracking-widest text-paper-muted">Billed to</div>
          <div className="mt-1 font-semibold">{invoice.to.name || "Client name"}</div>
          <div className="whitespace-pre-line text-paper-muted">{invoice.to.address}</div>
          {invoice.to.email && <div className="text-paper-muted">{invoice.to.email}</div>}
          {invoice.to.taxId && <div className="text-paper-muted">Tax ID: {invoice.to.taxId}</div>}
        </div>
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest text-paper-muted">Issued</div>
          <div className="num mt-1">{fmtDate(invoice.issueDate)}</div>
          <div className="mt-3 text-[10px] font-bold uppercase tracking-widest text-paper-muted">Terms</div>
          <div className="mt-1">{termsLabel}</div>
        </div>
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest text-paper-muted">Due</div>
          <div className="num mt-1 font-semibold">{fmtDate(invoice.dueDate)}</div>
          <div className="mt-3 text-[10px] font-bold uppercase tracking-widest text-paper-muted">Currency</div>
          <div className="mt-1">{cur}</div>
        </div>
      </div>

      <div className="mt-6 overflow-x-auto">
        <table className="w-full min-w-[520px] border-collapse text-left">
          <thead>
            <tr className="border-b-2 border-paper-foreground text-[10px] uppercase tracking-widest text-paper-muted">
              <th className="py-2 pr-2 font-bold">Description</th>
              <th className="px-2 py-2 text-right font-bold">Qty</th>
              <th className="px-2 py-2 text-right font-bold">Price</th>
              <th className="px-2 py-2 text-right font-bold">Disc.</th>
              <th className="px-2 py-2 text-right font-bold">Tax</th>
              <th className="py-2 pl-2 text-right font-bold">Amount{inclusive ? " (incl.)" : ""}</th>
            </tr>
          </thead>
          <tbody>
            {invoice.items.map((it, i) => (
              <tr key={it.id} className="border-b border-paper-line align-top">
                <td className="py-2.5 pr-2">{it.description || <span className="text-paper-muted">Item description</span>}</td>
                <td className="num px-2 py-2.5 text-right">{it.qty}</td>
                <td className="num px-2 py-2.5 text-right">{money(Math.round(it.unitPrice * 10 ** c.decimals))}</td>
                <td className="num px-2 py-2.5 text-right text-paper-muted">
                  {it.discount ? (it.discountType === "percent" ? `${it.discount}%` : money(Math.round(it.discount * 10 ** c.decimals))) : "—"}
                </td>
                <td className="num px-2 py-2.5 text-right text-paper-muted">{it.taxRate ? `${it.taxRate}%` : "—"}</td>
                <td className="num py-2.5 pl-2 text-right font-semibold">{money(c.lines[i]?.amount ?? 0)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-6 flex flex-col gap-6 sm:flex-row sm:justify-between">
        <div className="max-w-xs text-paper-muted">
          <div className="text-[10px] font-bold uppercase tracking-widest">Amount in words</div>
          <p className="mt-1 italic text-paper-foreground">{amountInWords(c.total, cur)}</p>
        </div>
        <dl className="w-full space-y-1.5 sm:w-72">
          <Row label="Subtotal" value={money(c.subtotal)} />
          {c.lineDiscountTotal > 0 && <Row label="Line discounts" value={`− ${money(c.lineDiscountTotal)}`} muted />}
          {c.invoiceDiscount > 0 && <Row label="Invoice discount" value={`− ${money(c.invoiceDiscount)}`} muted />}
          {c.taxGroups
            .filter((g) => g.rate > 0)
            .map((g) => (
              <Row key={g.rate} label={`${inclusive ? "Incl. tax" : "Tax"} ${g.rate}%`} value={money(g.tax)} muted />
            ))}
          {c.shipping > 0 && <Row label="Shipping" value={money(c.shipping)} muted />}
          {c.roundingAdjustment !== 0 && <Row label="Rounding" value={money(c.roundingAdjustment)} muted />}
          <div className="!mt-3 flex items-baseline justify-between border-t-2 border-paper-foreground pt-2">
            <dt className="font-bold">Total</dt>
            <dd className="num text-base font-bold">{money(c.total)}</dd>
          </div>
          {c.amountPaid > 0 && <Row label="Paid" value={`− ${money(c.amountPaid)}`} muted />}
          <div className="!mt-3 flex items-baseline justify-between rounded-md bg-ink px-3 py-2.5 text-ink-foreground">
            <dt className="text-xs font-bold uppercase tracking-widest">Balance due</dt>
            <dd className="num text-lg font-bold">{money(c.balanceDue)}</dd>
          </div>
        </dl>
      </div>

      {(c.earlyPay || invoice.lateFeeRate > 0 || fee?.fee) && (
        <div className="mt-6 space-y-1 rounded-md bg-primary-soft px-4 py-3 text-xs text-paper-foreground">
          {c.earlyPay && (
            <p>
              <strong>Early-payment offer:</strong> pay by {fmtDate(c.earlyPay.deadline)} and save {money(c.earlyPay.discount)} — settle {money(c.earlyPay.amount)}.
            </p>
          )}
          {invoice.lateFeeRate > 0 && (
            <p>
              <strong>Late fee:</strong> {invoice.lateFeeRate}% per 30 days ({invoice.lateFeeMode} interest) applies after {fmtDate(invoice.dueDate)}.
            </p>
          )}
          {fee && fee.fee > 0 && (
            <p className="font-semibold text-destructive">
              Overdue by {fee.days} day{fee.days === 1 ? "" : "s"} — accrued late fee {money(fee.fee)}.
            </p>
          )}
        </div>
      )}

      {(invoice.notes || invoice.paymentInfo) && (
        <div className="mt-6 grid gap-4 border-t border-paper-line pt-4 text-paper-muted sm:grid-cols-2">
          {invoice.notes && (
            <div>
              <div className="text-[10px] font-bold uppercase tracking-widest">Notes</div>
              <p className="mt-1 whitespace-pre-line text-paper-foreground">{invoice.notes}</p>
            </div>
          )}
          {invoice.paymentInfo && (
            <div>
              <div className="text-[10px] font-bold uppercase tracking-widest">Payment details</div>
              <p className="mt-1 whitespace-pre-line text-paper-foreground">{invoice.paymentInfo}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Row({ label, value, muted }: { label: string; value: string; muted?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-4">
      <dt className={muted ? "text-paper-muted" : ""}>{label}</dt>
      <dd className="num">{value}</dd>
    </div>
  );
}
