import { useEffect, useRef, useState, type InputHTMLAttributes, type ReactNode } from "react";

export function Field({ label, children, className = "", hint }: { label: string; children: ReactNode; className?: string; hint?: string }) {
  return (
    <label className={`block ${className}`}>
      <span className="label">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-muted-foreground">{hint}</span>}
    </label>
  );
}

type NumProps = Omit<InputHTMLAttributes<HTMLInputElement>, "value" | "onChange" | "type"> & {
  value: number;
  onChange: (n: number) => void;
};

/** Numeric input that lets users type "1." or clear the box without fighting the state. */
export function NumberInput({ value, onChange, className = "", ...rest }: NumProps) {
  const [text, setText] = useState(String(value));
  const last = useRef(value);

  useEffect(() => {
    if (value !== last.current) {
      last.current = value;
      if (parseFloat(text) !== value) setText(String(value));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  return (
    <input
      {...rest}
      type="text"
      inputMode="decimal"
      className={`input num ${className}`}
      value={text}
      onChange={(e) => {
        const v = e.target.value.replace(/[^0-9.\-]/g, "");
        setText(v);
        const n = parseFloat(v);
        const next = Number.isFinite(n) ? n : 0;
        last.current = next;
        onChange(next);
      }}
    />
  );
}

export function Section({ title, subtitle, children, action }: { title: string; subtitle?: string; children: ReactNode; action?: ReactNode }) {
  return (
    <section className="card p-5 sm:p-6">
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <h3 className="text-lg font-semibold">{title}</h3>
          {subtitle && <p className="text-sm text-muted-foreground">{subtitle}</p>}
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}
