import { Link } from "@tanstack/react-router";
import { Plus, ReceiptText } from "lucide-react";

export function Logo() {
  return (
    <Link to="/" className="flex items-center gap-2.5">
      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
        <ReceiptText className="h-4.5 w-4.5" size={18} />
      </span>
      <span className="font-display text-lg font-bold tracking-tight">Ledgerline</span>
    </Link>
  );
}

export function SiteHeader() {
  const link = "rounded-md px-3 py-1.5 text-sm font-semibold text-muted-foreground transition-colors hover:text-foreground";
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur print:hidden">
      <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4 sm:px-6">
        <Logo />
        <nav className="flex items-center gap-1">
          <Link to="/invoices" className={link} activeProps={{ className: `${link} !text-foreground` }}>
            Invoices
          </Link>
          <Link to="/engine" className={`${link} hidden sm:block`} activeProps={{ className: `${link} hidden !text-foreground sm:block` }}>
            Engine
          </Link>
          <Link to="/generator" className="btn btn-primary btn-sm ml-2">
            <Plus size={15} /> New invoice
          </Link>
        </nav>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="border-t border-border py-8 print:hidden">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-4 text-sm text-muted-foreground sm:flex-row sm:px-6">
        <Logo />
        <p>Invoices stay in your browser. Integer-exact math, every time.</p>
      </div>
    </footer>
  );
}
