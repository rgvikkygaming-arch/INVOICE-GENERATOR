import type { EffectiveStatus } from "@/lib/invoice-engine";

export function StatusChip({ status }: { status: EffectiveStatus }) {
  return <span className={`chip chip-${status}`}>{status}</span>;
}
