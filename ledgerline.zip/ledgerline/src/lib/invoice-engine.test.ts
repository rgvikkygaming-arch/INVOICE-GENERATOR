import { describe, expect, it } from "vitest";
import {
  allocate,
  amountInWords,
  blankInvoice,
  computeInvoice,
  dueDateFor,
  lateFee,
  newLine,
  nextInvoiceNumber,
  toMinor,
} from "./invoice-engine";

const make = (over: Record<string, unknown> = {}) => ({
  ...blankInvoice({ number: "X-1", issueDate: "2026-01-31" }),
  ...over,
});

describe("money", () => {
  it("converts 1.005 to 101 cents without float drift", () => {
    expect(toMinor(1.005, 2)).toBe(101);
    expect(toMinor(19.99, 2)).toBe(1999);
  });
});

describe("allocate (largest remainder)", () => {
  it("splits 100 cents over three equal weights into 34/33/33 summing to 100", () => {
    const out = allocate(100, [1, 1, 1]);
    expect(out).toEqual([34, 33, 33]);
    expect(out.reduce((a, b) => a + b, 0)).toBe(100);
  });
  it("always sums to the total", () => {
    const out = allocate(1001, [333, 667, 1, 17]);
    expect(out.reduce((a, b) => a + b, 0)).toBe(1001);
  });
});

describe("computeInvoice", () => {
  it("applies 10% line discount, 10% invoice discount and 20% tax", () => {
    const inv = make({
      items: [newLine({ qty: 2, unitPrice: 50, discount: 10, discountType: "percent", taxRate: 20 })],
      discountType: "percent",
      discount: 10,
    });
    const c = computeInvoice(inv);
    expect(c.subtotal).toBe(10000);
    expect(c.lineDiscountTotal).toBe(1000);
    expect(c.invoiceDiscount).toBe(900);
    expect(c.taxTotal).toBe(1620);
    expect(c.total).toBe(9720);
  });
  it("extracts tax from inclusive prices: 120.00 at 20% -> 20.00 tax", () => {
    const inv = make({ taxMode: "inclusive", items: [newLine({ qty: 1, unitPrice: 120, taxRate: 20 })] });
    const c = computeInvoice(inv);
    expect(c.taxTotal).toBe(2000);
    expect(c.total).toBe(12000);
  });
  it("applies cash rounding to the nearest 0.05", () => {
    const inv = make({ items: [newLine({ qty: 1, unitPrice: 10.02 })], rounding: 0.05 });
    const c = computeInvoice(inv);
    expect(c.total).toBe(1000);
    expect(c.roundingAdjustment).toBe(-2);
  });
  it("keeps line amounts summing to the discounted total", () => {
    const inv = make({
      items: [newLine({ unitPrice: 33.33 }), newLine({ unitPrice: 33.33 }), newLine({ unitPrice: 33.34 })],
      discountType: "fixed",
      discount: 10,
    });
    const c = computeInvoice(inv);
    expect(c.lines.reduce((a, l) => a + l.amount, 0)).toBe(c.subtotal - 1000);
  });
});

describe("dates, fees and numbering", () => {
  it("end-of-month terms land on the last day, incl. leap years", () => {
    expect(dueDateFor("2028-02-10", "eom")).toBe("2028-02-29");
    expect(dueDateFor("2026-01-31", "net30")).toBe("2026-03-02");
    expect(dueDateFor("2026-01-15", "eom30")).toBe("2026-03-02");
  });
  it("simple late fee: 1000.00 at 1.5%/30d for 60 days = 30.00", () => {
    expect(lateFee(100000, "2026-01-01", "2026-03-02", 1.5, "simple").fee).toBe(3000);
  });
  it("compound late fee exceeds simple fee", () => {
    const s = lateFee(100000, "2026-01-01", "2026-03-02", 1.5, "simple").fee;
    const c = lateFee(100000, "2026-01-01", "2026-03-02", 1.5, "compound").fee;
    expect(c).toBeGreaterThan(s);
  });
  it("increments the highest sequence for the same year", () => {
    const next = nextInvoiceNumber("INV-{YYYY}-{SEQ:4}", ["INV-2026-0007", "INV-2026-0012", "INV-2025-0099"], "2026-05-01");
    expect(next).toBe("INV-2026-0013");
    expect(nextInvoiceNumber("INV-{YYYY}-{SEQ:4}", ["INV-2026-0007"], "2027-01-02")).toBe("INV-2027-0001");
  });
  it("writes amounts in words, with Indian grouping for INR", () => {
    expect(amountInWords(123456, "USD")).toBe("One thousand two hundred and thirty-four dollars and fifty-six cents only");
    expect(amountInWords(12345000, "INR")).toBe("One lakh twenty-three thousand four hundred and fifty rupees only");
  });
});
