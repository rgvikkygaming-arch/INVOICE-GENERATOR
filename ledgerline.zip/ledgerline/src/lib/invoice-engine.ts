/**
 * Ledgerline invoice engine.
 *
 * Pure, framework-free algorithms. All money is held as INTEGER minor units
 * (cents, paise, yen…) so totals never drift by floating-point error.
 */

/* ------------------------------------------------------------------ */
/* Currencies & money                                                  */
/* ------------------------------------------------------------------ */

export type Currency = {
  code: string;
  symbol: string;
  decimals: number;
  locale: string;
  major: [string, string];
  minor: [string, string] | null;
  wordSystem: "intl" | "indian";
};

export const CURRENCIES: Currency[] = [
  { code: "USD", symbol: "$", decimals: 2, locale: "en-US", major: ["dollar", "dollars"], minor: ["cent", "cents"], wordSystem: "intl" },
  { code: "EUR", symbol: "€", decimals: 2, locale: "de-DE", major: ["euro", "euros"], minor: ["cent", "cents"], wordSystem: "intl" },
  { code: "GBP", symbol: "£", decimals: 2, locale: "en-GB", major: ["pound", "pounds"], minor: ["penny", "pence"], wordSystem: "intl" },
  { code: "INR", symbol: "₹", decimals: 2, locale: "en-IN", major: ["rupee", "rupees"], minor: ["paisa", "paise"], wordSystem: "indian" },
  { code: "AED", symbol: "د.إ", decimals: 2, locale: "en-AE", major: ["dirham", "dirhams"], minor: ["fils", "fils"], wordSystem: "intl" },
  { code: "CAD", symbol: "$", decimals: 2, locale: "en-CA", major: ["dollar", "dollars"], minor: ["cent", "cents"], wordSystem: "intl" },
  { code: "AUD", symbol: "$", decimals: 2, locale: "en-AU", major: ["dollar", "dollars"], minor: ["cent", "cents"], wordSystem: "intl" },
  { code: "SGD", symbol: "$", decimals: 2, locale: "en-SG", major: ["dollar", "dollars"], minor: ["cent", "cents"], wordSystem: "intl" },
  { code: "CHF", symbol: "Fr.", decimals: 2, locale: "de-CH", major: ["franc", "francs"], minor: ["rappen", "rappen"], wordSystem: "intl" },
  { code: "JPY", symbol: "¥", decimals: 0, locale: "ja-JP", major: ["yen", "yen"], minor: null, wordSystem: "intl" },
];

export function getCurrency(code: string): Currency {
  return CURRENCIES.find((c) => c.code === code) ?? (CURRENCIES[0] as Currency);
}

/** Decimal major units -> integer minor units, immune to 1.005*100 style drift. */
export function toMinor(amount: number, decimals: number): number {
  if (!Number.isFinite(amount)) return 0;
  return Math.round(Number((amount * 10 ** decimals).toPrecision(15)));
}

export function fromMinor(minor: number, decimals: number): number {
  return minor / 10 ** decimals;
}

export function formatMoney(minor: number, currencyCode: string): string {
  const c = getCurrency(currencyCode);
  try {
    return new Intl.NumberFormat(c.locale, {
      style: "currency",
      currency: c.code,
      minimumFractionDigits: c.decimals,
      maximumFractionDigits: c.decimals,
    }).format(fromMinor(minor, c.decimals));
  } catch {
    return `${c.symbol}${fromMinor(minor, c.decimals).toFixed(c.decimals)}`;
  }
}

/**
 * Largest-remainder (Hamilton) allocation: splits an integer `total` across
 * `weights` so the parts sum EXACTLY to total. No lost or invented pennies.
 */
export function allocate(total: number, weights: number[]): number[] {
  if (weights.length === 0) return [];
  const weightSum = weights.reduce((a, b) => a + b, 0);
  if (weightSum <= 0 || total === 0) return weights.map(() => 0);
  const sign = total < 0 ? -1 : 1;
  const abs = Math.abs(total);
  const raw = weights.map((w) => (abs * w) / weightSum);
  const floors = raw.map(Math.floor);
  let remainder = abs - floors.reduce((a, b) => a + b, 0);
  const order = raw
    .map((r, i) => ({ i, frac: r - Math.floor(r) }))
    .sort((a, b) => b.frac - a.frac || a.i - b.i);
  for (let k = 0; remainder > 0 && k < order.length; k++, remainder--) {
    const idx = order[k]!.i;
    floors[idx] = (floors[idx] ?? 0) + 1;
  }
  return floors.map((f) => f * sign);
}

/* ------------------------------------------------------------------ */
/* Dates & payment terms (UTC ISO yyyy-mm-dd, no timezone surprises)   */
/* ------------------------------------------------------------------ */

const DAY_MS = 86_400_000;

function parseISO(iso: string): number {
  const [y = 1970, m = 1, d = 1] = iso.split("-").map(Number);
  return Date.UTC(y, (m || 1) - 1, d || 1);
}
function toISO(ms: number): string {
  return new Date(ms).toISOString().slice(0, 10);
}
export function todayISO(): string {
  const n = new Date();
  const y = n.getFullYear();
  const m = String(n.getMonth() + 1).padStart(2, "0");
  const d = String(n.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}
export function addDays(iso: string, days: number): string {
  return toISO(parseISO(iso) + days * DAY_MS);
}
export function endOfMonth(iso: string): string {
  const [y = 1970, m = 1] = iso.split("-").map(Number);
  return toISO(Date.UTC(y, m, 0));
}
export function daysBetween(fromISO: string, toISOStr: string): number {
  return Math.round((parseISO(toISOStr) - parseISO(fromISO)) / DAY_MS);
}

export type Terms = "receipt" | "net7" | "net15" | "net30" | "net45" | "net60" | "eom" | "eom30" | "custom";

export const TERMS: { value: Terms; label: string }[] = [
  { value: "receipt", label: "Due on receipt" },
  { value: "net7", label: "Net 7" },
  { value: "net15", label: "Net 15" },
  { value: "net30", label: "Net 30" },
  { value: "net45", label: "Net 45" },
  { value: "net60", label: "Net 60" },
  { value: "eom", label: "End of month" },
  { value: "eom30", label: "30 days after end of month" },
  { value: "custom", label: "Custom date" },
];

export function dueDateFor(issueISO: string, terms: Terms, customISO?: string): string {
  switch (terms) {
    case "receipt":
      return issueISO;
    case "net7":
      return addDays(issueISO, 7);
    case "net15":
      return addDays(issueISO, 15);
    case "net30":
      return addDays(issueISO, 30);
    case "net45":
      return addDays(issueISO, 45);
    case "net60":
      return addDays(issueISO, 60);
    case "eom":
      return endOfMonth(issueISO);
    case "eom30":
      return addDays(endOfMonth(issueISO), 30);
    default:
      return customISO || issueISO;
  }
}

/* ------------------------------------------------------------------ */
/* Invoice numbering                                                   */
/* ------------------------------------------------------------------ */

function escapeRe(s: string) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/**
 * Tokens: {YYYY} {YY} {MM} {DD} {SEQ} {SEQ:4}. Finds the highest existing
 * sequence for the same resolved prefix (e.g. same year) and returns the next.
 */
export function nextInvoiceNumber(pattern: string, existing: string[], dateISO: string): string {
  const base = /\{SEQ(?::\d+)?\}/.test(pattern) ? pattern : `${pattern}-{SEQ:3}`;
  const [Y = "1970", M = "01", D = "01"] = dateISO.split("-");
  const re = /\{(YYYY|YY|MM|DD|SEQ)(?::(\d+))?\}/g;
  let src = "";
  let last = 0;
  let pad = 1;
  let m: RegExpExecArray | null;
  const parts: { lit: string; token?: string }[] = [];
  while ((m = re.exec(base))) {
    const lit = base.slice(last, m.index);
    last = re.lastIndex;
    src += escapeRe(lit);
    parts.push({ lit });
    switch (m[1]) {
      case "YYYY":
        src += Y;
        parts.push({ lit: Y });
        break;
      case "YY":
        src += Y.slice(2);
        parts.push({ lit: Y.slice(2) });
        break;
      case "MM":
        src += M;
        parts.push({ lit: M });
        break;
      case "DD":
        src += D;
        parts.push({ lit: D });
        break;
      default:
        src += "(\\d+)";
        pad = m[2] ? Number(m[2]) : 1;
        parts.push({ lit: "", token: "SEQ" });
    }
  }
  src += escapeRe(base.slice(last));
  parts.push({ lit: base.slice(last) });
  const matcher = new RegExp(`^${src}$`);
  let max = 0;
  for (const n of existing) {
    const hit = matcher.exec(n);
    if (hit) max = Math.max(max, Number(hit[1]));
  }
  const seq = String(max + 1).padStart(pad, "0");
  return parts.map((p) => (p.token ? seq : p.lit)).join("");
}

/* ------------------------------------------------------------------ */
/* Amount in words                                                     */
/* ------------------------------------------------------------------ */

const ONES = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"];
const TENS = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"];

function below100(n: number): string {
  if (n < 20) return ONES[n] ?? "";
  const t = TENS[Math.floor(n / 10)] ?? "";
  return n % 10 ? `${t}-${ONES[n % 10] ?? ""}` : t;
}
function below1000(n: number): string {
  const h = Math.floor(n / 100);
  const r = n % 100;
  const parts: string[] = [];
  if (h) parts.push(`${ONES[h] ?? ""} hundred`);
  if (r) parts.push(below100(r));
  return parts.join(" and ");
}

export function numberToWords(n: number, system: "intl" | "indian" = "intl"): string {
  n = Math.floor(Math.abs(n));
  if (n === 0) return "zero";
  const chunks: { value: number; label: string }[] = [];
  if (system === "indian") {
    const crore = Math.floor(n / 1e7);
    const lakh = Math.floor((n % 1e7) / 1e5);
    const thousand = Math.floor((n % 1e5) / 1e3);
    const rest = n % 1e3;
    if (crore) chunks.push({ value: crore, label: "crore" });
    if (lakh) chunks.push({ value: lakh, label: "lakh" });
    if (thousand) chunks.push({ value: thousand, label: "thousand" });
    if (rest) chunks.push({ value: rest, label: "" });
    return chunks
      .map((c) => `${c.value >= 100 && c.label === "crore" ? numberToWords(c.value, "indian") : below1000(c.value)}${c.label ? " " + c.label : ""}`)
      .join(" ");
  }
  const scales = ["", "thousand", "million", "billion", "trillion"];
  let i = 0;
  let rem = n;
  while (rem > 0) {
    const part = rem % 1000;
    if (part) chunks.unshift({ value: part, label: scales[i] ?? "" });
    rem = Math.floor(rem / 1000);
    i++;
  }
  return chunks.map((c) => `${below1000(c.value)}${c.label ? " " + c.label : ""}`).join(" ");
}

export function amountInWords(minor: number, currencyCode: string): string {
  const c = getCurrency(currencyCode);
  const abs = Math.abs(minor);
  const major = Math.floor(abs / 10 ** c.decimals);
  const sub = abs % 10 ** c.decimals;
  const majorWords = `${numberToWords(major, c.wordSystem)} ${major === 1 ? c.major[0] : c.major[1]}`;
  let out = majorWords;
  if (sub > 0 && c.minor) {
    out += ` and ${numberToWords(sub, c.wordSystem)} ${sub === 1 ? c.minor[0] : c.minor[1]}`;
  }
  out = `${minor < 0 ? "minus " : ""}${out} only`;
  return out.charAt(0).toUpperCase() + out.slice(1);
}

/* ------------------------------------------------------------------ */
/* Invoice model                                                       */
/* ------------------------------------------------------------------ */

export type DiscountType = "percent" | "fixed";
export type TaxMode = "exclusive" | "inclusive";
export type InvoiceStatus = "draft" | "sent" | "paid" | "void";

export type LineItem = {
  id: string;
  description: string;
  qty: number;
  unitPrice: number;
  discountType: DiscountType;
  discount: number;
  taxRate: number;
};

export type Party = { name: string; email: string; address: string; taxId: string };

export type Invoice = {
  id: string;
  number: string;
  status: InvoiceStatus;
  issueDate: string;
  terms: Terms;
  dueDate: string;
  currency: string;
  taxMode: TaxMode;
  from: Party;
  to: Party;
  items: LineItem[];
  discountType: DiscountType;
  discount: number;
  shipping: number;
  /** Cash rounding increment in major units (0 = off), e.g. 0.05 */
  rounding: number;
  amountPaid: number;
  lateFeeRate: number; // % per 30 days
  lateFeeMode: "simple" | "compound";
  earlyPayPct: number;
  earlyPayDays: number;
  notes: string;
  paymentInfo: string;
  createdAt: string;
  updatedAt: string;
};

export type ComputedLine = {
  id: string;
  gross: number;
  lineDiscount: number;
  net: number;
  invoiceDiscountShare: number;
  amount: number;
};

export type TaxGroup = { rate: number; taxable: number; tax: number };

export type TraceStep = { label: string; value: number; note?: string; kind?: "add" | "sub" | "total" | "info" };

export type Computed = {
  decimals: number;
  lines: ComputedLine[];
  subtotal: number;
  lineDiscountTotal: number;
  invoiceDiscount: number;
  taxGroups: TaxGroup[];
  taxableTotal: number;
  taxTotal: number;
  shipping: number;
  roundingAdjustment: number;
  total: number;
  amountPaid: number;
  balanceDue: number;
  earlyPay: { discount: number; amount: number; deadline: string } | null;
  trace: TraceStep[];
};

const clamp = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, Number.isFinite(n) ? n : 0));

export function computeInvoice(inv: Invoice): Computed {
  const { decimals } = getCurrency(inv.currency);
  const inclusive = inv.taxMode === "inclusive";

  // 1. Per-line gross, line discount, net
  const base = inv.items.map((it) => {
    const unit = toMinor(it.unitPrice, decimals);
    const gross = Math.round(Math.max(0, Number.isFinite(it.qty) ? it.qty : 0) * unit);
    const lineDiscount =
      it.discountType === "percent"
        ? Math.round((gross * clamp(it.discount, 0, 100)) / 100)
        : Math.min(Math.max(0, toMinor(it.discount, decimals)), gross);
    return { id: it.id, gross, lineDiscount, net: gross - lineDiscount, taxRate: clamp(it.taxRate, 0, 100) };
  });

  const subtotal = base.reduce((a, l) => a + l.gross, 0);
  const lineDiscountTotal = base.reduce((a, l) => a + l.lineDiscount, 0);
  const afterLine = subtotal - lineDiscountTotal;

  // 2. Invoice-level discount, spread by largest remainder
  const invoiceDiscount =
    inv.discountType === "percent"
      ? Math.round((afterLine * clamp(inv.discount, 0, 100)) / 100)
      : Math.min(Math.max(0, toMinor(inv.discount, decimals)), afterLine);
  const shares = allocate(invoiceDiscount, base.map((l) => l.net));

  const lines: ComputedLine[] = base.map((l, i) => ({
    id: l.id,
    gross: l.gross,
    lineDiscount: l.lineDiscount,
    net: l.net,
    invoiceDiscountShare: shares[i] ?? 0,
    amount: l.net - (shares[i] ?? 0),
  }));
  const afterDiscounts = afterLine - invoiceDiscount;

  // 3. Tax, grouped by rate (round once per rate group, as tax authorities expect)
  const groupMap = new Map<number, number>();
  lines.forEach((l, i) => {
    const rate = base[i]?.taxRate ?? 0;
    groupMap.set(rate, (groupMap.get(rate) ?? 0) + l.amount);
  });
  const taxGroups: TaxGroup[] = [...groupMap.entries()]
    .sort((a, b) => a[0] - b[0])
    .map(([rate, sum]) => {
      if (inclusive) {
        const taxable = Math.round((sum * 100) / (100 + rate));
        return { rate, taxable, tax: sum - taxable };
      }
      return { rate, taxable: sum, tax: Math.round((sum * rate) / 100) };
    });
  const taxTotal = taxGroups.reduce((a, g) => a + g.tax, 0);
  const taxableTotal = taxGroups.reduce((a, g) => a + g.taxable, 0);

  // 4. Shipping (untaxed), cash rounding
  const shipping = Math.max(0, toMinor(inv.shipping, decimals));
  const preRound = (inclusive ? afterDiscounts : afterDiscounts + taxTotal) + shipping;
  const inc = inv.rounding > 0 ? toMinor(inv.rounding, decimals) : 0;
  const rounded = inc > 1 ? Math.round(preRound / inc) * inc : preRound;
  const roundingAdjustment = rounded - preRound;
  const total = rounded;

  const amountPaid = Math.max(0, toMinor(inv.amountPaid, decimals));
  const balanceDue = Math.max(0, total - amountPaid);

  // 5. Early-payment incentive
  const earlyPay =
    inv.earlyPayPct > 0 && inv.earlyPayDays > 0
      ? (() => {
          const discount = Math.round((total * clamp(inv.earlyPayPct, 0, 100)) / 100);
          return { discount, amount: total - discount, deadline: addDays(inv.issueDate, Math.floor(inv.earlyPayDays)) };
        })()
      : null;

  const trace: TraceStep[] = [
    { label: "Gross line totals", value: subtotal, note: `${base.length} line${base.length === 1 ? "" : "s"}, qty × unit price`, kind: "add" },
    { label: "Line discounts", value: -lineDiscountTotal, kind: "sub" },
    {
      label: "Invoice discount",
      value: -invoiceDiscount,
      kind: "sub",
      ...(invoiceDiscount ? { note: "Spread across lines by largest remainder" } : {}),
    },
    { label: "Discounted amount", value: afterDiscounts, kind: "total" },
    ...taxGroups.map<TraceStep>((g) => ({
      label: `Tax @ ${g.rate}%`,
      value: g.tax,
      note: inclusive ? "Extracted from tax-inclusive prices" : "On taxable base",
      kind: inclusive ? "info" : "add",
    })),
    { label: "Shipping", value: shipping, kind: "add" },
  ];
  if (roundingAdjustment !== 0) {
    trace.push({ label: "Cash rounding", value: roundingAdjustment, note: `Nearest ${inv.rounding}`, kind: roundingAdjustment > 0 ? "add" : "sub" });
  }
  trace.push({ label: "Total", value: total, kind: "total" });
  if (amountPaid) trace.push({ label: "Paid", value: -amountPaid, kind: "sub" });
  trace.push({ label: "Balance due", value: balanceDue, kind: "total" });

  return {
    decimals,
    lines,
    subtotal,
    lineDiscountTotal,
    invoiceDiscount,
    taxGroups,
    taxableTotal,
    taxTotal,
    shipping,
    roundingAdjustment,
    total,
    amountPaid,
    balanceDue,
    earlyPay,
    trace,
  };
}

/* ------------------------------------------------------------------ */
/* Late fees & status                                                  */
/* ------------------------------------------------------------------ */

export function lateFee(
  balanceMinor: number,
  dueISO: string,
  asOfISO: string,
  ratePctPer30Days: number,
  mode: "simple" | "compound",
): { days: number; fee: number } {
  const days = Math.max(0, daysBetween(dueISO, asOfISO));
  if (days === 0 || ratePctPer30Days <= 0 || balanceMinor <= 0) return { days, fee: 0 };
  const r = ratePctPer30Days / 100;
  const periods = days / 30;
  const fee = mode === "simple" ? balanceMinor * r * periods : balanceMinor * (Math.pow(1 + r, periods) - 1);
  return { days, fee: Math.round(fee) };
}

export type EffectiveStatus = InvoiceStatus | "overdue";

export function effectiveStatus(inv: Invoice, asOfISO: string): EffectiveStatus {
  if (inv.status === "sent" && inv.dueDate < asOfISO) return "overdue";
  return inv.status;
}

/* ------------------------------------------------------------------ */
/* Factories & samples                                                 */
/* ------------------------------------------------------------------ */

export function newId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `id-${Math.random().toString(36).slice(2)}-${Date.now().toString(36)}`;
}

export const emptyParty = (): Party => ({ name: "", email: "", address: "", taxId: "" });

export function newLine(partial: Partial<LineItem> = {}): LineItem {
  return { id: newId(), description: "", qty: 1, unitPrice: 0, discountType: "percent", discount: 0, taxRate: 0, ...partial };
}

export function blankInvoice(opts: { number: string; issueDate: string; from?: Party; currency?: string; taxRate?: number }): Invoice {
  const now = new Date().toISOString();
  return {
    id: newId(),
    number: opts.number,
    status: "draft",
    issueDate: opts.issueDate,
    terms: "net30",
    dueDate: dueDateFor(opts.issueDate, "net30"),
    currency: opts.currency ?? "USD",
    taxMode: "exclusive",
    from: opts.from ?? emptyParty(),
    to: emptyParty(),
    items: [newLine({ taxRate: opts.taxRate ?? 0 })],
    discountType: "percent",
    discount: 0,
    shipping: 0,
    rounding: 0,
    amountPaid: 0,
    lateFeeRate: 0,
    lateFeeMode: "simple",
    earlyPayPct: 0,
    earlyPayDays: 10,
    notes: "",
    paymentInfo: "",
    createdAt: now,
    updatedAt: now,
  };
}

export function sampleInvoice(issueDate = "2026-10-01"): Invoice {
  const inv = blankInvoice({ number: "INV-2026-0042", issueDate });
  return {
    ...inv,
    id: "sample",
    status: "sent",
    from: {
      name: "Northwind Studio",
      email: "billing@northwind.studio",
      address: "14 Harbour Lane\nBristol BS1 4QA",
      taxId: "GB 123 4567 89",
    },
    to: {
      name: "Alder & Finch Ltd.",
      email: "accounts@alderfinch.co",
      address: "92 Market Street\nManchester M1 1PW",
      taxId: "",
    },
    items: [
      { id: "s1", description: "Brand identity system", qty: 1, unitPrice: 2400, discountType: "percent", discount: 0, taxRate: 20 },
      { id: "s2", description: "Website design — 12 hours", qty: 12, unitPrice: 95.5, discountType: "percent", discount: 10, taxRate: 20 },
      { id: "s3", description: "Printed guidelines (A4, bound)", qty: 5, unitPrice: 18.33, discountType: "fixed", discount: 4, taxRate: 5 },
    ],
    discountType: "percent",
    discount: 5,
    shipping: 12,
    lateFeeRate: 1.5,
    earlyPayPct: 2,
    earlyPayDays: 10,
    notes: "Thank you for your business. Please quote the invoice number with your payment.",
    paymentInfo: "Bank: Northwind Studio · Sort 20-45-67 · Acc 12345678",
  };
}
