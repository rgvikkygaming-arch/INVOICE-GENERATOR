import { computeInvoice, fromMinor, type Invoice } from "./invoice-engine";

function csvCell(v: string | number) {
  const s = String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function download(name: string, text: string, mime: string) {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}

export function downloadInvoiceCsv(inv: Invoice) {
  const c = computeInvoice(inv);
  const rows: (string | number)[][] = [
    ["Invoice", inv.number],
    ["Issued", inv.issueDate],
    ["Due", inv.dueDate],
    ["Client", inv.to.name],
    [],
    ["Description", "Qty", "Unit price", "Discount", "Tax %", "Amount"],
    ...inv.items.map((it, i) => [
      it.description,
      it.qty,
      it.unitPrice,
      `${it.discount}${it.discountType === "percent" ? "%" : ""}`,
      it.taxRate,
      fromMinor(c.lines[i]?.amount ?? 0, c.decimals).toFixed(c.decimals),
    ]),
    [],
    ["Subtotal", fromMinor(c.subtotal, c.decimals).toFixed(c.decimals)],
    ["Tax", fromMinor(c.taxTotal, c.decimals).toFixed(c.decimals)],
    ["Total", fromMinor(c.total, c.decimals).toFixed(c.decimals)],
    ["Balance due", fromMinor(c.balanceDue, c.decimals).toFixed(c.decimals)],
  ];
  download(`${inv.number}.csv`, rows.map((r) => r.map(csvCell).join(",")).join("\n"), "text/csv");
}

export function downloadInvoicesCsv(list: Invoice[]) {
  const rows: (string | number)[][] = [
    ["Number", "Client", "Status", "Issued", "Due", "Currency", "Total", "Balance due"],
    ...list.map((i) => {
      const c = computeInvoice(i);
      return [
        i.number,
        i.to.name,
        i.status,
        i.issueDate,
        i.dueDate,
        i.currency,
        fromMinor(c.total, c.decimals).toFixed(c.decimals),
        fromMinor(c.balanceDue, c.decimals).toFixed(c.decimals),
      ];
    }),
  ];
  download("invoices.csv", rows.map((r) => r.map(csvCell).join(",")).join("\n"), "text/csv");
}

export function downloadInvoiceJson(inv: Invoice) {
  download(`${inv.number}.json`, JSON.stringify(inv, null, 2), "application/json");
}
