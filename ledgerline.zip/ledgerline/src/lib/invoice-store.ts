import { useSyncExternalStore } from "react";
import { blankInvoice, emptyParty, nextInvoiceNumber, todayISO, type Invoice, type Party } from "./invoice-engine";

const INVOICES_KEY = "ledgerline.invoices.v1";
const SETTINGS_KEY = "ledgerline.settings.v1";

export type Settings = {
  from: Party;
  numberPattern: string;
  currency: string;
  defaultTaxRate: number;
};

const DEFAULT_SETTINGS: Settings = {
  from: emptyParty(),
  numberPattern: "INV-{YYYY}-{SEQ:4}",
  currency: "USD",
  defaultTaxRate: 0,
};

const EMPTY_INVOICES: Invoice[] = [];
let invoicesCache: Invoice[] | null = null;
let settingsCache: Settings | null = null;
const listeners = new Set<() => void>();

function emit() {
  listeners.forEach((l) => l());
}
function subscribe(cb: () => void) {
  listeners.add(cb);
  const onStorage = (e: StorageEvent) => {
    if (e.key === INVOICES_KEY) invoicesCache = null;
    if (e.key === SETTINGS_KEY) settingsCache = null;
    cb();
  };
  window.addEventListener("storage", onStorage);
  return () => {
    listeners.delete(cb);
    window.removeEventListener("storage", onStorage);
  };
}

function readInvoices(): Invoice[] {
  if (typeof window === "undefined") return EMPTY_INVOICES;
  if (invoicesCache) return invoicesCache;
  try {
    const raw = window.localStorage.getItem(INVOICES_KEY);
    invoicesCache = raw ? (JSON.parse(raw) as Invoice[]) : [];
  } catch {
    invoicesCache = [];
  }
  return invoicesCache;
}
function readSettings(): Settings {
  if (typeof window === "undefined") return DEFAULT_SETTINGS;
  if (settingsCache) return settingsCache;
  try {
    const raw = window.localStorage.getItem(SETTINGS_KEY);
    settingsCache = raw ? { ...DEFAULT_SETTINGS, ...(JSON.parse(raw) as Partial<Settings>) } : DEFAULT_SETTINGS;
  } catch {
    settingsCache = DEFAULT_SETTINGS;
  }
  return settingsCache;
}

export function useInvoices(): Invoice[] {
  return useSyncExternalStore(subscribe, readInvoices, () => EMPTY_INVOICES);
}
export function useSettings(): Settings {
  return useSyncExternalStore(subscribe, readSettings, () => DEFAULT_SETTINGS);
}

export function getInvoices(): Invoice[] {
  return readInvoices();
}
export function getInvoice(id: string): Invoice | undefined {
  return readInvoices().find((i) => i.id === id);
}
export function getSettings(): Settings {
  return readSettings();
}

function persistInvoices(next: Invoice[]) {
  invoicesCache = next;
  window.localStorage.setItem(INVOICES_KEY, JSON.stringify(next));
  emit();
}

export function saveInvoice(inv: Invoice) {
  const list = readInvoices();
  const stamped = { ...inv, updatedAt: new Date().toISOString() };
  const exists = list.some((i) => i.id === inv.id);
  persistInvoices(exists ? list.map((i) => (i.id === inv.id ? stamped : i)) : [stamped, ...list]);
}
export function deleteInvoice(id: string) {
  persistInvoices(readInvoices().filter((i) => i.id !== id));
}
export function saveSettings(patch: Partial<Settings>) {
  settingsCache = { ...readSettings(), ...patch };
  window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(settingsCache));
  emit();
}

export function createDraft(): Invoice {
  const s = readSettings();
  const issueDate = todayISO();
  const number = nextInvoiceNumber(
    s.numberPattern,
    readInvoices().map((i) => i.number),
    issueDate,
  );
  return blankInvoice({ number, issueDate, from: s.from, currency: s.currency, taxRate: s.defaultTaxRate });
}
