import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { ArrowDown, ArrowUp, Copy, Download, FileJson, Plus, Printer, RefreshCw, Save, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Field, NumberInput, Section } from "@/components/form";
import { InvoiceDocument } from "@/components/invoice-document";
import { StatusChip } from "@/components/status-chip";
import { downloadInvoiceCsv, downloadInvoiceJson } from "@/lib/export";
import {
  CURRENCIES,
  TERMS,
  computeInvoice,
  dueDateFor,
  effectiveStatus,
  formatMoney,
  newId,
  newLine,
  nextInvoiceNumber,
  todayISO,
  type Invoice,
  type InvoiceStatus,
  type LineItem,
  type Party,
  type Terms,
} from "@/lib/invoice-engine";
import { createDraft, getInvoice, saveInvoice, saveSettings, useInvoices, useSettings } from "@/lib/invoice-store";

export const Route = createFileRoute("/generator")({
  validateSearch: (s: Record<string, unknown>): { id?: string } => (typeof s["id"] === "string" ? { id: s["id"] } : {}),
  head: () => ({
    meta: [
      { title: "Invoice generator — Ledgerline" },
      { name: "description", content: "Build an invoice with live totals, tax grouping, discounts and a step-by-step calculation trace. Print to PDF or export CSV." },
      { property: "og:title", content: "Invoice generator — Ledgerline" },
      { property: "og:description", content: "Live-calculating invoice editor with print-ready output and a transparent calculation trace." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Generator,
});

type Tab = "edit" | "preview" | "trace";

function Generator() {
  const { id } = Route.useSearch();
  const navigate = useNavigate();
  const settings = useSettings();
  const all = useInvoices();
  const [inv, setInv] = useState<Invoice | null>(null);
  const [tab, setTab] = useState<Tab>("edit");
  const [dirty, setDirty] = useState(false);

  useEffect(() => {
    setInv((id ? getInvoice(id) : undefined) ?? createDraft());
    setDirty(false);
  }, [id]);

  const computed = useMemo(() => (inv ? computeInvoice(inv) : null), [inv]);

  if (!inv || !computed) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <div className="h-8 w-48 animate-pulse rounded bg-secondary" />
        <div className="mt-6 grid gap-6 lg:grid-cols-2">
          <div className="h-96 animate-pulse rounded-xl bg-secondary" />
          <div className="h-96 animate-pulse rounded-xl bg-secondary" />
        </div>
      </div>
    );
  }

  const set = (patch: Partial<Invoice>) => {
    setInv((p) => (p ? { ...p, ...patch } : p));
    setDirty(true);
  };
  const setParty = (key: "from" | "to", patch: Partial<Party>) => set({ [key]: { ...inv[key], ...patch } } as Partial<Invoice>);
  const setItem = (itemId: string, patch: Partial<LineItem>) => set({ items: inv.items.map((it) => (it.id === itemId ? { ...it, ...patch } : it)) });
  const moveItem = (idx: number, dir: -1 | 1) => {
    const items = [...inv.items];
    const j = idx + dir;
    if (j < 0 || j >= items.length) return;
    const a = items[idx]!;
    items[idx] = items[j]!;
    items[j] = a;
    set({ items });
  };
  const setIssue = (issueDate: string) => set({ issueDate, dueDate: inv.terms === "custom" ? inv.dueDate : dueDateFor(issueDate, inv.terms) });
  const setTerms = (terms: Terms) => set({ terms, dueDate: terms === "custom" ? inv.dueDate : dueDateFor(inv.issueDate, terms) });
  const nextNumber = () =>
    nextInvoiceNumber(
      settings.numberPattern,
      all.filter((i) => i.id !== inv.id).map((i) => i.number),
      inv.issueDate,
    );

  const money = (n: number) => formatMoney(n, inv.currency);
  const status = effectiveStatus(inv, todayISO());

  const onSave = () => {
    saveInvoice(inv);
    saveSettings({ from: inv.from, currency: inv.currency });
    setDirty(false);
    toast.success(`Saved ${inv.number}`);
    if (id !== inv.id) navigate({ to: "/generator", search: { id: inv.id }, replace: true });
  };

  const rightTab = tab === "trace" ? "trace" : "preview";

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 print:max-w-none print:p-0">
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3 print:hidden">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-bold sm:text-3xl">{inv.number || "New invoice"}</h1>
          <StatusChip status={status} />
          {dirty && <span className="text-xs font-semibold text-warning">Unsaved</span>}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button className="btn btn-outline btn-sm" onClick={() => downloadInvoiceCsv(inv)} title="Export CSV">
            <Download size={15} /> <span className="hidden sm:inline">CSV</span>
          </button>
          <button className="btn btn-outline btn-sm" onClick={() => downloadInvoiceJson(inv)} title="Export JSON">
            <FileJson size={15} /> <span className="hidden sm:inline">JSON</span>
          </button>
          <button className="btn btn-outline btn-sm" onClick={() => window.print()}>
            <Printer size={15} /> Print / PDF
          </button>
          <button className="btn btn-primary btn-sm" onClick={onSave}>
            <Save size={15} /> Save
          </button>
        </div>
      </div>

      <div className="seg mb-4 w-full lg:hidden print:hidden">
        {(["edit", "preview", "trace"] as Tab[]).map((t) => (
          <button key={t} data-active={tab === t} onClick={() => setTab(t)} className="flex-1 capitalize">
            {t}
          </button>
        ))}
      </div>

      <div className="grid items-start gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)] print:block">
        {/* ---------------- Editor ---------------- */}
        <div className={`space-y-5 ${tab === "edit" ? "block" : "hidden"} lg:block print:hidden`}>
          <Section title="Details">
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Invoice number">
                <div className="flex gap-2">
                  <input className="input num" value={inv.number} onChange={(e) => set({ number: e.target.value })} />
                  <button className="btn btn-outline btn-icon" title="Generate next number" onClick={() => set({ number: nextNumber() })}>
                    <RefreshCw size={15} />
                  </button>
                </div>
              </Field>
              <Field label="Numbering pattern" hint="Tokens: {YYYY} {YY} {MM} {DD} {SEQ:4}">
                <input className="input num" value={settings.numberPattern} onChange={(e) => saveSettings({ numberPattern: e.target.value })} />
              </Field>
              <Field label="Issue date">
                <input type="date" className="input" value={inv.issueDate} onChange={(e) => e.target.value && setIssue(e.target.value)} />
              </Field>
              <Field label="Payment terms">
                <select className="input" value={inv.terms} onChange={(e) => setTerms(e.target.value as Terms)}>
                  {TERMS.map((t) => (
                    <option key={t.value} value={t.value}>
                      {t.label}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Due date">
                <input
                  type="date"
                  className="input"
                  value={inv.dueDate}
                  onChange={(e) => e.target.value && set({ dueDate: e.target.value, terms: "custom" })}
                />
              </Field>
              <Field label="Status">
                <select className="input" value={inv.status} onChange={(e) => set({ status: e.target.value as InvoiceStatus })}>
                  <option value="draft">Draft</option>
                  <option value="sent">Sent</option>
                  <option value="paid">Paid</option>
                  <option value="void">Void</option>
                </select>
              </Field>
              <Field label="Currency">
                <select className="input" value={inv.currency} onChange={(e) => set({ currency: e.target.value })}>
                  {CURRENCIES.map((c) => (
                    <option key={c.code} value={c.code}>
                      {c.code} — {c.symbol}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Prices are">
                <div className="seg w-full">
                  {(["exclusive", "inclusive"] as const).map((m) => (
                    <button key={m} data-active={inv.taxMode === m} onClick={() => set({ taxMode: m })} className="flex-1">
                      {m === "exclusive" ? "Tax extra" : "Tax included"}
                    </button>
                  ))}
                </div>
              </Field>
            </div>
          </Section>

          <div className="grid gap-5 md:grid-cols-2">
            <PartyForm title="From" party={inv.from} onChange={(p) => setParty("from", p)} />
            <PartyForm title="Billed to" party={inv.to} onChange={(p) => setParty("to", p)} />
          </div>

          <Section
            title="Line items"
            action={
              <button className="btn btn-outline btn-sm" onClick={() => set({ items: [...inv.items, newLine({ taxRate: settings.defaultTaxRate })] })}>
                <Plus size={15} /> Add line
              </button>
            }
          >
            <div className="space-y-3">
              {inv.items.map((it, idx) => (
                <div key={it.id} className="rounded-lg border border-border bg-background/60 p-3">
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-6">
                    <Field label="Description" className="col-span-2 sm:col-span-6">
                      <input className="input" placeholder="What did you deliver?" value={it.description} onChange={(e) => setItem(it.id, { description: e.target.value })} />
                    </Field>
                    <Field label="Qty">
                      <NumberInput value={it.qty} onChange={(n) => setItem(it.id, { qty: n })} />
                    </Field>
                    <Field label="Unit price">
                      <NumberInput value={it.unitPrice} onChange={(n) => setItem(it.id, { unitPrice: n })} />
                    </Field>
                    <Field label="Discount" className="col-span-2">
                      <div className="flex gap-1.5">
                        <NumberInput value={it.discount} onChange={(n) => setItem(it.id, { discount: n })} />
                        <select
                          className="input !w-20 shrink-0"
                          value={it.discountType}
                          onChange={(e) => setItem(it.id, { discountType: e.target.value as LineItem["discountType"] })}
                        >
                          <option value="percent">%</option>
                          <option value="fixed">{inv.currency}</option>
                        </select>
                      </div>
                    </Field>
                    <Field label="Tax %">
                      <NumberInput value={it.taxRate} onChange={(n) => setItem(it.id, { taxRate: n })} />
                    </Field>
                    <div>
                      <span className="label">Amount</span>
                      <div className="num flex h-[2.4rem] items-center text-sm font-bold">{money(computed.lines[idx]?.amount ?? 0)}</div>
                    </div>
                  </div>
                  <div className="mt-2 flex justify-end gap-1">
                    <button className="btn btn-ghost btn-icon" title="Move up" disabled={idx === 0} onClick={() => moveItem(idx, -1)}>
                      <ArrowUp size={15} />
                    </button>
                    <button className="btn btn-ghost btn-icon" title="Move down" disabled={idx === inv.items.length - 1} onClick={() => moveItem(idx, 1)}>
                      <ArrowDown size={15} />
                    </button>
                    <button
                      className="btn btn-ghost btn-icon"
                      title="Duplicate"
                      onClick={() => {
                        const items = [...inv.items];
                        items.splice(idx + 1, 0, { ...it, id: newId() });
                        set({ items });
                      }}
                    >
                      <Copy size={15} />
                    </button>
                    <button
                      className="btn btn-ghost btn-danger btn-icon"
                      title="Remove"
                      disabled={inv.items.length === 1}
                      onClick={() => set({ items: inv.items.filter((x) => x.id !== it.id) })}
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </Section>

          <Section title="Adjustments" subtitle="Applied after line items, in this order.">
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Invoice discount">
                <div className="flex gap-1.5">
                  <NumberInput value={inv.discount} onChange={(n) => set({ discount: n })} />
                  <select className="input !w-20 shrink-0" value={inv.discountType} onChange={(e) => set({ discountType: e.target.value as Invoice["discountType"] })}>
                    <option value="percent">%</option>
                    <option value="fixed">{inv.currency}</option>
                  </select>
                </div>
              </Field>
              <Field label="Shipping (untaxed)">
                <NumberInput value={inv.shipping} onChange={(n) => set({ shipping: n })} />
              </Field>
              <Field label="Cash rounding">
                <select className="input" value={inv.rounding} onChange={(e) => set({ rounding: Number(e.target.value) })}>
                  <option value={0}>None</option>
                  <option value={0.05}>Nearest 0.05</option>
                  <option value={0.1}>Nearest 0.10</option>
                  <option value={0.5}>Nearest 0.50</option>
                  <option value={1}>Nearest 1.00</option>
                </select>
              </Field>
              <Field label="Amount already paid">
                <NumberInput value={inv.amountPaid} onChange={(n) => set({ amountPaid: n })} />
              </Field>
            </div>
          </Section>

          <Section title="Fees & incentives">
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Late fee % per 30 days">
                <NumberInput value={inv.lateFeeRate} onChange={(n) => set({ lateFeeRate: n })} />
              </Field>
              <Field label="Interest type">
                <select className="input" value={inv.lateFeeMode} onChange={(e) => set({ lateFeeMode: e.target.value as Invoice["lateFeeMode"] })}>
                  <option value="simple">Simple</option>
                  <option value="compound">Compound</option>
                </select>
              </Field>
              <Field label="Early-payment discount %">
                <NumberInput value={inv.earlyPayPct} onChange={(n) => set({ earlyPayPct: n })} />
              </Field>
              <Field label="…if paid within (days)">
                <NumberInput value={inv.earlyPayDays} onChange={(n) => set({ earlyPayDays: n })} />
              </Field>
            </div>
          </Section>

          <Section title="Notes">
            <div className="grid gap-3">
              <Field label="Notes to client">
                <textarea className="input" value={inv.notes} onChange={(e) => set({ notes: e.target.value })} />
              </Field>
              <Field label="Payment details">
                <textarea className="input" value={inv.paymentInfo} onChange={(e) => set({ paymentInfo: e.target.value })} />
              </Field>
            </div>
          </Section>
        </div>

        {/* ---------------- Preview / Trace ---------------- */}
        <div className={`${tab === "edit" ? "hidden" : "block"} lg:sticky lg:top-20 lg:block print:static print:block`}>
          <div className="seg mb-3 hidden lg:inline-flex print:hidden">
            {(["preview", "trace"] as const).map((t) => (
              <button key={t} data-active={rightTab === t} onClick={() => setTab(t)} className="capitalize">
                {t === "trace" ? "Calculation trace" : "Preview"}
              </button>
            ))}
          </div>
          <div className={`${rightTab === "trace" ? "hidden print:block" : ""} lg:max-h-[calc(100vh-9rem)] lg:overflow-y-auto lg:rounded-md print:max-h-none print:overflow-visible`}>
            <InvoiceDocument invoice={inv} computed={computed} />
          </div>
          {rightTab === "trace" && <TracePanel inv={inv} computed={computed} />}
        </div>
      </div>
    </div>
  );
}

function PartyForm({ title, party, onChange }: { title: string; party: Party; onChange: (p: Partial<Party>) => void }) {
  return (
    <Section title={title}>
      <div className="grid gap-3">
        <Field label="Name">
          <input className="input" value={party.name} onChange={(e) => onChange({ name: e.target.value })} />
        </Field>
        <Field label="Email">
          <input className="input" type="email" value={party.email} onChange={(e) => onChange({ email: e.target.value })} />
        </Field>
        <Field label="Address">
          <textarea className="input" value={party.address} onChange={(e) => onChange({ address: e.target.value })} />
        </Field>
        <Field label="Tax / VAT ID">
          <input className="input" value={party.taxId} onChange={(e) => onChange({ taxId: e.target.value })} />
        </Field>
      </div>
    </Section>
  );
}

function TracePanel({ inv, computed: c }: { inv: Invoice; computed: ReturnType<typeof computeInvoice> }) {
  const money = (n: number) => formatMoney(n, inv.currency);
  const kindClass = { add: "", sub: "text-muted-foreground", total: "font-bold border-t border-border pt-2", info: "text-muted-foreground" } as const;
  return (
    <div className="card space-y-6 p-5 sm:p-6 lg:max-h-[calc(100vh-9rem)] lg:overflow-y-auto print:hidden">
      <div>
        <h3 className="text-lg font-semibold">Calculation trace</h3>
        <p className="text-sm text-muted-foreground">Every step, in integer {inv.currency} minor units, rendered back as money.</p>
        <ol className="mt-4 space-y-2">
          {c.trace.map((s, i) => (
            <li key={i} className={`flex items-baseline justify-between gap-3 ${kindClass[s.kind ?? "add"]}`}>
              <span>
                <span className="num mr-2 text-xs text-primary">{String(i + 1).padStart(2, "0")}</span>
                {s.label}
                {s.note && <span className="block pl-7 text-xs font-normal text-muted-foreground">{s.note}</span>}
              </span>
              <span className="num shrink-0">{money(s.value)}</span>
            </li>
          ))}
        </ol>
      </div>

      <div>
        <h4 className="font-display font-semibold">Largest-remainder allocation</h4>
        <p className="text-sm text-muted-foreground">How the {money(c.invoiceDiscount)} invoice discount lands on each line, to the exact cent.</p>
        <div className="mt-3 overflow-x-auto">
          <table className="w-full min-w-[420px] text-left text-sm">
            <thead className="text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="py-1.5">Line</th>
                <th className="text-right">Net</th>
                <th className="text-right">Share</th>
                <th className="text-right">Amount</th>
              </tr>
            </thead>
            <tbody>
              {c.lines.map((l, i) => (
                <tr key={l.id} className="border-t border-border">
                  <td className="max-w-[10rem] truncate py-1.5">{inv.items[i]?.description || `Line ${i + 1}`}</td>
                  <td className="num text-right">{money(l.net)}</td>
                  <td className="num text-right text-muted-foreground">− {money(l.invoiceDiscountShare)}</td>
                  <td className="num text-right font-semibold">{money(l.amount)}</td>
                </tr>
              ))}
              <tr className="border-t-2 border-foreground font-bold">
                <td className="py-1.5">Sum</td>
                <td className="num text-right">{money(c.lines.reduce((a, l) => a + l.net, 0))}</td>
                <td className="num text-right">− {money(c.lines.reduce((a, l) => a + l.invoiceDiscountShare, 0))}</td>
                <td className="num text-right">{money(c.lines.reduce((a, l) => a + l.amount, 0))}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div>
        <h4 className="font-display font-semibold">Tax by rate</h4>
        <table className="mt-2 w-full text-left text-sm">
          <thead className="text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="py-1.5">Rate</th>
              <th className="text-right">Taxable</th>
              <th className="text-right">Tax</th>
            </tr>
          </thead>
          <tbody>
            {c.taxGroups.map((g) => (
              <tr key={g.rate} className="border-t border-border">
                <td className="num py-1.5">{g.rate}%</td>
                <td className="num text-right">{money(g.taxable)}</td>
                <td className="num text-right font-semibold">{money(g.tax)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
