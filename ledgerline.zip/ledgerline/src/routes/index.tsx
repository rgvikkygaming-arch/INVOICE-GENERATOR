import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Calculator, CalendarClock, Hash, Percent, Scale, Type } from "lucide-react";
import { InvoiceDocument } from "@/components/invoice-document";
import { computeInvoice, sampleInvoice } from "@/lib/invoice-engine";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Ledgerline — Invoices that do the math right" },
      {
        name: "description",
        content:
          "A modern invoice generator built on exact integer money math: largest-remainder discounts, grouped tax, cash rounding, late fees and smart numbering.",
      },
      { property: "og:title", content: "Ledgerline — Invoices that do the math right" },
      {
        property: "og:description",
        content: "Generate print-ready invoices where every cent adds up. Discounts, tax, rounding and late fees handled by a tested engine.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const FEATURES = [
  {
    icon: Calculator,
    title: "Integer-exact money",
    body: "Every amount is stored in minor units. 1.005 becomes 101 cents, never 100.49999.",
    code: "toMinor(1.005, 2) → 101",
  },
  {
    icon: Scale,
    title: "Largest-remainder discounts",
    body: "An invoice-wide discount is spread over lines so the parts always equal the whole.",
    code: "allocate(100, [1,1,1]) → [34,33,33]",
  },
  {
    icon: Percent,
    title: "Tax by rate group",
    body: "Exclusive or inclusive pricing, rounded once per rate — the way tax returns expect it.",
    code: "120.00 incl. 20% → tax 20.00",
  },
  {
    icon: Hash,
    title: "Pattern numbering",
    body: "Tokens like {YYYY} and {SEQ:4} find the highest sequence and roll over each year.",
    code: "INV-2026-0012 → INV-2026-0013",
  },
  {
    icon: CalendarClock,
    title: "Terms & late fees",
    body: "Net 30, end-of-month, leap years, plus simple or compound interest on overdue balances.",
    code: "eom30 · 2026-01-15 → 2026-03-02",
  },
  {
    icon: Type,
    title: "Amount in words",
    body: "Cheque-ready wording, with lakh and crore grouping for rupee invoices.",
    code: "₹1,23,450 → One lakh twenty-three…",
  },
];

const STEPS = ["Gross lines", "Line discounts", "Invoice discount", "Tax by rate", "Cash rounding", "Total"];

function Index() {
  const sample = sampleInvoice();
  const computed = computeInvoice(sample);

  return (
    <div>
      <section className="relative overflow-hidden border-b border-border" style={{ backgroundImage: "var(--gradient-hero)" }}>
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-14 sm:px-6 lg:grid-cols-[1.05fr_1fr] lg:py-24">
          <div className="rise">
            <span className="chip bg-accent text-accent-foreground">Algorithm-first invoicing</span>
            <h1 className="mt-5 text-5xl font-extrabold leading-[0.98] sm:text-6xl lg:text-7xl">
              Invoices that do the <span className="highlight">math right.</span>
            </h1>
            <p className="mt-6 max-w-xl text-lg text-muted-foreground">
              Build a polished, print-ready invoice in minutes. Underneath, a tested engine keeps every cent honest: discounts, tax, rounding, late fees and numbering.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/generator" className="btn btn-primary px-5 py-3.5">
                Create an invoice <ArrowRight size={16} />
              </Link>
              <Link to="/engine" className="btn btn-outline px-5 py-3.5">
                Explore the engine
              </Link>
            </div>
            <dl className="mt-10 grid max-w-md grid-cols-3 gap-4 border-t border-border pt-6">
              {[
                ["0", "float errors"],
                ["10", "currencies"],
                ["100%", "in your browser"],
              ].map(([v, l]) => (
                <div key={l}>
                  <dt className="num text-2xl font-bold text-primary">{v}</dt>
                  <dd className="text-xs uppercase tracking-wider text-muted-foreground">{l}</dd>
                </div>
              ))}
            </dl>
          </div>
          <div className="rise relative [animation-delay:150ms]">
            <div className="absolute -inset-3 -z-10 rotate-2 rounded-3xl bg-primary-soft" />
            <div className="origin-top scale-[0.97] lg:-rotate-1">
              <InvoiceDocument invoice={sample} computed={computed} asOf="2026-10-05" />
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-24">
        <div className="max-w-2xl">
          <h2 className="text-3xl font-bold sm:text-4xl">Six algorithms, one honest total.</h2>
          <p className="mt-3 text-muted-foreground">Each rule lives in a small pure function with unit tests, so the number on the page is the number you can defend.</p>
        </div>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <article key={f.title} className="card p-6 transition-transform hover:-translate-y-1">
              <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary-soft text-primary">
                <f.icon size={20} />
              </span>
              <h3 className="mt-4 text-lg font-semibold">{f.title}</h3>
              <p className="mt-1.5 text-sm text-muted-foreground">{f.body}</p>
              <code className="num mt-4 block rounded-md bg-ink px-3 py-2 text-xs text-ink-foreground">{f.code}</code>
            </article>
          ))}
        </div>
      </section>

      <section className="border-y border-border bg-secondary/60">
        <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
          <h2 className="text-2xl font-bold sm:text-3xl">How a total is built</h2>
          <ol className="mt-8 grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
            {STEPS.map((s, i) => (
              <li key={s} className="card relative p-4">
                <span className="num text-xs font-bold text-primary">0{i + 1}</span>
                <p className="mt-1 font-display font-semibold">{s}</p>
              </li>
            ))}
          </ol>
          <p className="mt-6 text-sm text-muted-foreground">Open any invoice and switch to the Trace tab to watch each step with the real figures.</p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 text-center sm:px-6 lg:py-24">
        <h2 className="mx-auto max-w-2xl text-3xl font-bold sm:text-5xl">Ready to send an invoice you can trust?</h2>
        <Link to="/generator" className="btn btn-ink mt-8 px-6 py-4">
          Start your first invoice <ArrowRight size={16} />
        </Link>
      </section>
    </div>
  );
}
