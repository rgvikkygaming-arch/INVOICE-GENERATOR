import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { CheckCircle2, Copy, Download, FilePlus2, Pencil, Search, Sparkles, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { StatusChip } from "@/components/status-chip";
import { downloadInvoicesCsv } from "@/lib/export";
import {
  computeInvoice,
  dueDateFor,
  effectiveStatus,
  formatMoney,
  lateFee,
  newId,
  nextInvoiceNumber,
  sampleInvoice,
  todayISO,
  type EffectiveStatus,
  type Invoice,
} from "@/lib/invoice-engine";
import { deleteInvoice, saveInvoice, useInvoices } from "@/lib/invoice-store";

export const Route = createFileRoute("/invoices")({
  head: () => ({
    meta: [
      { title: "Your invoices — Ledgerline" },
      { name: "description", content: "Track drafts, sent, paid and overdue invoices with outstanding balances and accrued late fees." },
      { property: "og:title", content: "Your invoices — Ledgerline" },
      { property: "og:description", content: "A live ledger of every invoice, with outstanding totals and accrued late fees." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: InvoicesPage,
});

type Filter = "all" | EffectiveStatus;

function InvoicesPage() {
  const invoices = useInvoices();
  const [filter, setFilter] = useState<Filter>("all");
  const [q, setQ] = useState("");
  const today = todayISO();

  const rows = useMemo(
    () =>
      invoices.map((inv) => {
        const c = computeInvoice(inv);
        const status = effectiveStatus(inv, today);
        const fee = status === "overdue" ? lateFee(c.balanceDue, inv.dueDate, today, inv.lateFeeRate, inv.lateFeeMode) : { days: 0, fee: 0 };
        return { inv, c, status, fee };
      }),
    [invoices, today],
  );

  const stats = useMemo(() => {
    const byCur = new Map<string, { outstanding: number; overdue: number; paid: number; fees: number }>();
    for (const r of rows) {
      const s = byCur.get(r.inv.currency) ?? { outstanding: 0, overdue: 0, paid: 0, fees: 0 };
      if (r.status === "sent" || r.status === "overdue") s.outstanding += r.c.balanceDue;
      if (r.status === "overdue") {
        s.overdue += r.c.balanceDue;
        s.fees += r.fee.fee;
      }
      if (r.status === "paid") s.paid += r.c.total;
      byCur.set(r.inv.currency, s);
    }
    return [...byCur.entries()];
  }, [rows]);

  const visible = rows.filter(
    (r) =>
      (filter === "all" || r.status === filter) &&
      (!q || `${r.inv.number} ${r.inv.to.name}`.toLowerCase().includes(q.toLowerCase())),
  );

  const duplicate = (inv: Invoice) => {
    const copy: Invoice = {
      ...inv,
      id: newId(),
      status: "draft",
      amountPaid: 0,
      issueDate: today,
      number: nextInvoiceNumber("INV-{YYYY}-{SEQ:4}", invoices.map((i) => i.number), today),
      items: inv.items.map((i) => ({ ...i, id: newId() })),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    saveInvoice(copy);
    toast.success(`Duplicated as ${copy.number}`);
  };

  const loadSample = () => {
    saveInvoice({ ...sampleInvoice(), id: newId(), issueDate: today, dueDate: dueDateFor(today, "net30") });
    toast.success("Sample invoice added");
  };

  const filters: Filter[] = ["all", "draft", "sent", "overdue", "paid", "void"];

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold sm:text-4xl">Invoices</h1>
          <p className="mt-1 text-muted-foreground">Everything you have billed, saved in this browser.</p>
        </div>
        <div className="flex gap-2">
          <button className="btn btn-outline" disabled={!invoices.length} onClick={() => downloadInvoicesCsv(invoices)}>
            <Download size={15} /> Export CSV
          </button>
          <Link to="/generator" className="btn btn-primary">
            <FilePlus2 size={15} /> New invoice
          </Link>
        </div>
      </div>

      {invoices.length === 0 ? (
        <div className="card mt-8 grid-lines px-6 py-16 text-center">
          <h2 className="text-2xl font-bold">No invoices yet</h2>
          <p className="mx-auto mt-2 max-w-md text-muted-foreground">Create your first invoice, or drop in a sample to see tax, discounts and late fees at work.</p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Link to="/generator" className="btn btn-primary">
              <FilePlus2 size={15} /> Create invoice
            </Link>
            <button className="btn btn-outline" onClick={loadSample}>
              <Sparkles size={15} /> Load sample
            </button>
          </div>
        </div>
      ) : (
        <>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label="Invoices" lines={[String(invoices.length)]} />
            <Stat label="Outstanding" lines={stats.map(([cur, s]) => formatMoney(s.outstanding, cur))} />
            <Stat label="Overdue + late fees" tone="danger" lines={stats.map(([cur, s]) => `${formatMoney(s.overdue, cur)} + ${formatMoney(s.fees, cur)}`)} />
            <Stat label="Collected" tone="success" lines={stats.map(([cur, s]) => formatMoney(s.paid, cur))} />
          </div>

          <div className="mt-8 flex flex-wrap items-center justify-between gap-3">
            <div className="seg flex-wrap">
              {filters.map((f) => (
                <button key={f} data-active={filter === f} onClick={() => setFilter(f)} className="capitalize">
                  {f}
                </button>
              ))}
            </div>
            <div className="relative w-full sm:w-64">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input className="input !pl-9" placeholder="Search number or client" value={q} onChange={(e) => setQ(e.target.value)} />
            </div>
          </div>

          <div className="card mt-4 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[720px] text-left text-sm">
                <thead className="bg-secondary/70 text-xs uppercase tracking-wider text-muted-foreground">
                  <tr>
                    <th className="px-4 py-3">Invoice</th>
                    <th className="px-4 py-3">Client</th>
                    <th className="px-4 py-3">Due</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3 text-right">Total</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {visible.map(({ inv, c, status, fee }) => (
                    <tr key={inv.id} className="border-t border-border hover:bg-secondary/40">
                      <td className="px-4 py-3">
                        <Link to="/generator" search={{ id: inv.id }} className="num font-semibold text-primary hover:underline">
                          {inv.number}
                        </Link>
                      </td>
                      <td className="px-4 py-3">{inv.to.name || <span className="text-muted-foreground">—</span>}</td>
                      <td className="num px-4 py-3">
                        {inv.dueDate}
                        {fee.days > 0 && <span className="block text-xs text-destructive">{fee.days}d late{fee.fee ? ` · +${formatMoney(fee.fee, inv.currency)}` : ""}</span>}
                      </td>
                      <td className="px-4 py-3">
                        <StatusChip status={status} />
                      </td>
                      <td className="num px-4 py-3 text-right font-semibold">{formatMoney(c.total, inv.currency)}</td>
                      <td className="px-4 py-3">
                        <div className="flex justify-end gap-1">
                          {inv.status !== "paid" && inv.status !== "void" && (
                            <button
                              className="btn btn-ghost btn-icon"
                              title="Mark as paid"
                              onClick={() => {
                                saveInvoice({ ...inv, status: "paid", amountPaid: c.total / 10 ** c.decimals });
                                toast.success(`${inv.number} marked paid`);
                              }}
                            >
                              <CheckCircle2 size={16} />
                            </button>
                          )}
                          <Link to="/generator" search={{ id: inv.id }} className="btn btn-ghost btn-icon" title="Edit">
                            <Pencil size={16} />
                          </Link>
                          <button className="btn btn-ghost btn-icon" title="Duplicate" onClick={() => duplicate(inv)}>
                            <Copy size={16} />
                          </button>
                          <button
                            className="btn btn-ghost btn-danger btn-icon"
                            title="Delete"
                            onClick={() => {
                              if (window.confirm(`Delete ${inv.number}?`)) deleteInvoice(inv.id);
                            }}
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {visible.length === 0 && (
                    <tr>
                      <td colSpan={6} className="px-4 py-10 text-center text-muted-foreground">
                        No invoices match.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function Stat({ label, lines, tone }: { label: string; lines: string[]; tone?: "danger" | "success" }) {
  const color = tone === "danger" ? "text-destructive" : tone === "success" ? "text-primary" : "text-foreground";
  return (
    <div className="card p-5">
      <div className="label !mb-2">{label}</div>
      {lines.map((l, i) => (
        <div key={i} className={`num text-xl font-bold ${color}`}>
          {l}
        </div>
      ))}
    </div>
  );
}
