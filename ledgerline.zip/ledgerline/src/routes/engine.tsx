import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState, type ReactNode } from "react";
import { Field, NumberInput } from "@/components/form";
import {
  CURRENCIES,
  TERMS,
  allocate,
  amountInWords,
  dueDateFor,
  formatMoney,
  lateFee,
  nextInvoiceNumber,
  toMinor,
  type Terms,
} from "@/lib/invoice-engine";

export const Route = createFileRoute("/engine")({
  head: () => ({
    meta: [
      { title: "The engine — Ledgerline" },
      { name: "description", content: "Play with the invoice algorithms: largest-remainder allocation, payment-term dates, late-fee interest, numbering patterns and amount in words." },
      { property: "og:title", content: "The engine — Ledgerline" },
      { property: "og:description", content: "Interactive demos of the algorithms that keep invoice totals exact." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: EnginePage,
});

function Panel({ n, title, blurb, children }: { n: string; title: string; blurb: string; children: ReactNode }) {
  return (
    <section className="card p-5 sm:p-6">
      <div className="flex items-baseline gap-3">
        <span className="num text-sm font-bold text-primary">{n}</span>
        <h2 className="text-xl font-semibold">{title}</h2>
      </div>
      <p className="mt-1 text-sm text-muted-foreground">{blurb}</p>
      <div className="mt-5">{children}</div>
    </section>
  );
}

function EnginePage() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <h1 className="text-3xl font-bold sm:text-5xl">
        The <span className="highlight">engine</span>
      </h1>
      <p className="mt-3 max-w-2xl text-muted-foreground">The same pure functions that power every invoice, with the dials exposed. Change an input and watch the output.</p>
      <div className="mt-8 grid gap-5 lg:grid-cols-2">
        <Allocation />
        <Dates />
        <Numbering />
        <Words />
      </div>
    </div>
  );
}

function Allocation() {
  const [total, setTotal] = useState(100);
  const [weights, setWeights] = useState("1, 1, 1");
  const ws = useMemo(() => weights.split(/[,\s]+/).map(Number).filter((n) => Number.isFinite(n) && n > 0), [weights]);
  const minor = toMinor(total, 2);
  const sum = ws.reduce((a, b) => a + b, 0);
  const naive = ws.map((w) => Math.round((minor * w) / sum));
  const fair = allocate(minor, ws);
  const add = (a: number[]) => a.reduce((x, y) => x + y, 0);

  return (
    <Panel n="01" title="Largest-remainder allocation" blurb="Splitting an amount by naive rounding loses or invents cents. The fair split always lands exactly on the total.">
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Amount to split">
          <NumberInput value={total} onChange={setTotal} />
        </Field>
        <Field label="Weights (comma separated)">
          <input className="input num" value={weights} onChange={(e) => setWeights(e.target.value)} />
        </Field>
      </div>
      {ws.length > 0 && (
        <table className="mt-5 w-full text-sm">
          <thead className="text-left text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="py-1.5">Part</th>
              <th className="text-right">Naive rounding</th>
              <th className="text-right">Largest remainder</th>
            </tr>
          </thead>
          <tbody>
            {ws.map((w, i) => (
              <tr key={i} className="border-t border-border">
                <td className="num py-1.5">{w}</td>
                <td className="num text-right text-muted-foreground">{formatMoney(naive[i] ?? 0, "USD")}</td>
                <td className="num text-right font-semibold">{formatMoney(fair[i] ?? 0, "USD")}</td>
              </tr>
            ))}
            <tr className="border-t-2 border-foreground font-bold">
              <td className="py-1.5">Sum</td>
              <td className={`num text-right ${add(naive) !== minor ? "text-destructive" : ""}`}>{formatMoney(add(naive), "USD")}</td>
              <td className="num text-right text-primary">{formatMoney(add(fair), "USD")}</td>
            </tr>
          </tbody>
        </table>
      )}
    </Panel>
  );
}

function Dates() {
  const [issue, setIssue] = useState("2026-10-10");
  const [terms, setTerms] = useState<Terms>("net30");
  const [balance, setBalance] = useState(1000);
  const [rate, setRate] = useState(1.5);
  const [asOf, setAsOf] = useState("2026-12-20");
  const due = dueDateFor(issue, terms);
  const simple = lateFee(toMinor(balance, 2), due, asOf, rate, "simple");
  const comp = lateFee(toMinor(balance, 2), due, asOf, rate, "compound");

  return (
    <Panel n="02" title="Payment terms & late fees" blurb="Calendar maths in UTC (leap years included), then simple or compound interest per 30 days.">
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Issue date">
          <input type="date" className="input" value={issue} onChange={(e) => e.target.value && setIssue(e.target.value)} />
        </Field>
        <Field label="Terms">
          <select className="input" value={terms} onChange={(e) => setTerms(e.target.value as Terms)}>
            {TERMS.filter((t) => t.value !== "custom").map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Balance">
          <NumberInput value={balance} onChange={setBalance} />
        </Field>
        <Field label="Fee % per 30 days">
          <NumberInput value={rate} onChange={setRate} />
        </Field>
        <Field label="Check date" className="sm:col-span-2">
          <input type="date" className="input" value={asOf} onChange={(e) => e.target.value && setAsOf(e.target.value)} />
        </Field>
      </div>
      <dl className="mt-5 space-y-2 text-sm">
        <Out label="Due date" value={due} />
        <Out label="Days overdue" value={String(simple.days)} />
        <Out label="Simple fee" value={formatMoney(simple.fee, "USD")} />
        <Out label="Compound fee" value={formatMoney(comp.fee, "USD")} />
      </dl>
    </Panel>
  );
}

function Numbering() {
  const [pattern, setPattern] = useState("INV-{YYYY}-{SEQ:4}");
  const [existing, setExisting] = useState("INV-2026-0007\nINV-2026-0012\nINV-2025-0099");
  const [date, setDate] = useState("2026-10-10");
  const next = nextInvoiceNumber(pattern, existing.split("\n").map((s) => s.trim()).filter(Boolean), date);

  return (
    <Panel n="03" title="Smart numbering" blurb="Resolves date tokens, scans existing numbers that share the prefix, and increments the highest sequence.">
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Pattern" hint="{YYYY} {YY} {MM} {DD} {SEQ:n}">
          <input className="input num" value={pattern} onChange={(e) => setPattern(e.target.value)} />
        </Field>
        <Field label="Invoice date">
          <input type="date" className="input" value={date} onChange={(e) => e.target.value && setDate(e.target.value)} />
        </Field>
        <Field label="Existing numbers (one per line)" className="sm:col-span-2">
          <textarea className="input num" value={existing} onChange={(e) => setExisting(e.target.value)} />
        </Field>
      </div>
      <div className="mt-5 rounded-lg bg-ink px-4 py-3 text-ink-foreground">
        <div className="text-xs uppercase tracking-widest opacity-70">Next number</div>
        <div className="num text-2xl font-bold">{next}</div>
      </div>
    </Panel>
  );
}

function Words() {
  const [amount, setAmount] = useState(123450.75);
  const [cur, setCur] = useState("INR");
  return (
    <Panel n="04" title="Amount in words" blurb="International grouping by default; rupee invoices use lakh and crore.">
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Amount">
          <NumberInput value={amount} onChange={setAmount} />
        </Field>
        <Field label="Currency">
          <select className="input" value={cur} onChange={(e) => setCur(e.target.value)}>
            {CURRENCIES.map((c) => (
              <option key={c.code} value={c.code}>
                {c.code}
              </option>
            ))}
          </select>
        </Field>
      </div>
      <div className="mt-5 rounded-lg bg-primary-soft px-4 py-3">
        <div className="num text-lg font-bold">{formatMoney(toMinor(amount, CURRENCIES.find((c) => c.code === cur)!.decimals), cur)}</div>
        <p className="mt-1 italic">{amountInWords(toMinor(amount, CURRENCIES.find((c) => c.code === cur)!.decimals), cur)}</p>
      </div>
    </Panel>
  );
}

function Out({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between border-t border-border pt-2">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="num font-bold">{value}</dd>
    </div>
  );
}
